package com.cts.bajaj.repositories;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cts.bajaj.models.CTS_USER;

public interface UserRepository extends JpaRepository<CTS_USER,Integer>{

}
