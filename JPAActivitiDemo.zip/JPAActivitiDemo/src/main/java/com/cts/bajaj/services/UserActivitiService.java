package com.cts.bajaj.services;

import java.util.Collections;
import java.util.HashMap;
import java.util.Map;

import org.activiti.engine.RuntimeService;
import org.activiti.engine.TaskService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cts.bajaj.models.CTS_USER;


@Component
public class UserActivitiService {
	
	@Autowired
	private RuntimeService runTimeService;
	
	@Autowired
	private TaskService taskService;
	
	
	public String startProcess(CTS_USER user)
	{
		/*Map<String, Object> variables = new HashMap<String, Object>();
		variables.put("firstName", user.getFirstName());		
		variables.put("lastName", user.getLastName());
		variables.put("dob", user.getDob());*/
		
		//Map<String, Object> variables=Collections.<String, Object>singletonMap("ctsuser", user);
		Map<String, Object> variables = new HashMap<String, Object>();
		variables.put("ctsuser", user);
		variables.put("manager", new String("Amit"));
		runTimeService.startProcessInstanceByKey("jpaProcess", variables);
 
		return "Process started";
	}
	

}
