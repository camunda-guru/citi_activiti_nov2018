package com.cts.bajaj.listeners;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.DelegateTask;
import org.activiti.engine.delegate.ExecutionListener;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.delegate.TaskListener;
import org.springframework.stereotype.Component;

@Component
public class InterviewListener implements  TaskListener{

	
	@Override
	public void notify(DelegateTask execution) {
		// TODO Auto-generated method stub
		execution.setVariable("outcome", "good");
	}

}
