package com.cts.bajaj.controllers;

import java.text.ParseException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cts.bajaj.models.CTS_USER;

import com.cts.bajaj.services.UserActivitiService;

@RestController
public class UserController {

	@Autowired
	private UserActivitiService userActivitiService;
	@GetMapping(path="/")
	public String home()
	{
		
		return "Project Started";
		
	}
	
	@CrossOrigin(origins = "*")
	@PostMapping(path="/onBoarding")
	public String addInfo(@RequestBody final CTS_USER user) throws ParseException
	{
		System.out.println("Hitting....");
		return userActivitiService.startProcess(user);
		
	}
	
}
