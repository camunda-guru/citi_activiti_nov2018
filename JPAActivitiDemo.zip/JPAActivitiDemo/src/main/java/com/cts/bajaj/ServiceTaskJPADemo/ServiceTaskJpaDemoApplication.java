package com.cts.bajaj.ServiceTaskJPADemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.autoconfigure.security.servlet.SecurityAutoConfiguration;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EnableAutoConfiguration
@ComponentScan(basePackages="com.cts.bajaj.*")
@EnableJpaRepositories(basePackages="com.cts.bajaj.*")
@EntityScan(basePackages="com.cts.bajaj.*")

public class ServiceTaskJpaDemoApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceTaskJpaDemoApplication.class, args);
	}
}
