package com.cts.bajaj.services;

import java.util.Date;

import org.activiti.engine.delegate.DelegateExecution;
import org.activiti.engine.delegate.JavaDelegate;
import org.activiti.engine.impl.delegate.ActivityBehavior;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;
import org.springframework.web.context.support.SpringBeanAutowiringSupport;

import com.cts.bajaj.models.CTS_USER;
import com.cts.bajaj.repositories.UserRepository;

@Service
public class UserJPAService implements JavaDelegate {
    @Autowired
 	private UserRepository repo;
   

	/*public void addUser(CTS_USER user)
    {
		
        System.out.println(user.getFirstName());
    	repo.save(user);
    	
    }*/


	@Override
	public void execute(DelegateExecution execution) {
		// TODO Auto-generated method stub
		repo.save((CTS_USER)execution.getVariable("ctsuser"));
	}

	
    
}
